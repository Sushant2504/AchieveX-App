package com.app.achievex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
