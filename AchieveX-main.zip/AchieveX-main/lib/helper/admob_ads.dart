import 'dart:io';

import 'package:admob_flutter/admob_flutter.dart';

class AdmobAds {
   AdmobBannerSize? bannerSize;
  late AdmobInterstitial interstitialAd;
  late AdmobReward rewardAd;



initAds(){
 bannerSize = AdmobBannerSize.BANNER;

    interstitialAd = AdmobInterstitial(
      adUnitId: getInterstitialAdUnitId()!,
      listener: (AdmobAdEvent event, Map<String, dynamic>? args) {
        if (event == AdmobAdEvent.closed) interstitialAd.load();
        handleEvent(event, args, 'Interstitial');
      },
    );

    rewardAd = AdmobReward(
      adUnitId: getRewardBasedVideoAdUnitId()!,
      listener: (AdmobAdEvent event, Map<String, dynamic>? args) {
        if (event == AdmobAdEvent.closed) rewardAd.load();
        handleEvent(event, args, 'Reward');
      },
    );

    interstitialAd.load();
    rewardAd.load();

  }



   void handleEvent(
      AdmobAdEvent event, Map<String, dynamic>? args, String adType) {
    switch (event) {
      case AdmobAdEvent.loaded:
        // showSnackBar('New Admob $adType Ad loaded!');
        break;
      case AdmobAdEvent.opened:
        // showSnackBar('Admob $adType Ad opened!');
        break;
      case AdmobAdEvent.closed:
        // showSnackBar('Admob $adType Ad closed!');
        break;
      case AdmobAdEvent.failedToLoad:
        // showSnackBar('Admob $adType failed to load. :(');
        break;
      case AdmobAdEvent.rewarded:
        // showDialog(
        //   context: scaffoldState.currentContext!,
        //   builder: (BuildContext context) {
        //     return WillPopScope(
        //       onWillPop: () async {
        //         ScaffoldMessenger.of(context).hideCurrentSnackBar();
        //         return true;
        //       },
        //       child: AlertDialog(
        //         content: Column(
        //           mainAxisSize: MainAxisSize.min,
        //           children: <Widget>[
        //             Text('Reward callback fired. Thanks Andrew!'),
        //             Text('Type: ${args!['type']}'),
        //             Text('Amount: ${args['amount']}'),
        //           ],
        //         ),
        //       ),
        //     );
        //   },
        // );
      
      
        break;
      default:
    }
  
  

}
}
String? getBannerAdUnitId() {
  // if (Platform.isIOS) {
  //   return 'ca-app-pub-3940256099942544/2934735716';
  // } else if (Platform.isAndroid) {
    return 'ca-app-pub-3940256099942544/6300978111';
  // }
  // return null;
}

String? getInterstitialAdUnitId() {
  if (Platform.isIOS) {
    return 'ca-app-pub-3940256099942544/4411468910';
  } else if (Platform.isAndroid) {
    return 'ca-app-pub-3940256099942544/1033173712';
  }
  return null;
}

String? getRewardBasedVideoAdUnitId() {
  if (Platform.isIOS) {
    return 'ca-app-pub-3940256099942544/1712485313';
  } else if (Platform.isAndroid) {
    return 'ca-app-pub-3940256099942544/5224354917';
  }
  return null;
}
