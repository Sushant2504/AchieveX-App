import 'dart:async';
import 'package:achievex/data/repository/authentication_repo.dart';
import 'package:achievex/provider/home_provider.dart';
import 'package:achievex/utils/app_constants.dart';
import 'package:achievex/utils/routes/routes_name.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../data/model/response/base/api_response.dart';
import '../data/model/response/user_model.dart';
import '../helper/api_checker.dart';
import '../utils/utils.dart';

class AppAuthProvider extends ChangeNotifier {
  final AuthRepo? authRepo;

  AppAuthProvider({required this.authRepo});
  FirebaseAuth auth = FirebaseAuth.instance;
  bool otpVisibility = false;
  User? user;

  Map<String, dynamic> _data = <String, dynamic>{};
  // for registration section
  bool _isLoading = false;
  String verificationIDs = "";

  bool get isLoading => _isLoading;
  Map<String, dynamic> get data => _data;
  late AppAuthProvider appAuthProvider;

  String? _registrationErrorMessage = '';

  String? get registrationErrorMessage => _registrationErrorMessage;
  int? currentTime;

  Future<Map<String, dynamic>> registration(Data signUpModel) async {
    _isLoading = true;
    _registrationErrorMessage = '';
    notifyListeners();
    ApiResponse apiResponse = await authRepo!.registration(signUpModel);

    if (apiResponse.response != null &&
        apiResponse.response!.statusCode == 200) {
      _data = apiResponse.response?.data;
      // responseModel = ResponseModel(true, 'successful');
    } else {
      if (apiResponse.response != null) {
        _data = apiResponse.response!.data;
      }
      _registrationErrorMessage =
          ApiChecker.getError(apiResponse).errors![0].message;
      // responseModel = ResponseModel(false, _registrationErrorMessage);
    }
    _isLoading = false;
    notifyListeners();
    return _data;
  }

  Future<Map<String, dynamic>> checkPhone(String mobile) async {
    _isLoading = true;
    _registrationErrorMessage = '';
    notifyListeners();
    ApiResponse apiResponse = await authRepo!.checkPhoneExist(mobile);

    if (apiResponse.response != null &&
        apiResponse.response!.statusCode == 200) {
      _data = apiResponse.response?.data;
      debugPrint("Success${apiResponse.response?.data['msg']}");
      if (apiResponse.response?.data['msg'] == 'Mobile Number Found') {
      } else {
        Utils.showToast('Mobile Number Not Found');
      }
    } else {
      _data = apiResponse.response!.data;
      _registrationErrorMessage =
          ApiChecker.getError(apiResponse).errors![0].message;
      debugPrint("Error===>" + apiResponse.response?.data);
      // responseModel = ResponseModel(false, _registrationErrorMessage);
    }
    _isLoading = false;
    notifyListeners();
    return _data;
  }

  int _start = 30;
  bool _timerRunning = false;

  int get start => _start;
  bool get timerRunning => _timerRunning;

  void startTimer() {
    _timerRunning = true;

    const oneSec = Duration(seconds: 1);
    Timer.periodic(oneSec, (Timer timer) {
      if (_start == 0) {
        if (_start == 0) {
          _start = 30;
        }
        _timerRunning = false;
        timer.cancel();
      } else {
        _start--;
      }
      notifyListeners();
    });
  }

  Future<bool> saveUser(Data data) async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    sp.setString(AppConstants.userName, data.fName.toString());
    sp.setString(AppConstants.phone, data.phone.toString());
    sp.setString(AppConstants.email, data.email.toString());
    sp.setInt(AppConstants.userid, data.id!.toInt());
    sp.setString("referBy", data.referBy.toString());
    sp.setBool(AppConstants.isLogin, true);

    notifyListeners();
    return true;
  }

  Future<Data> getUser() async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    return Data(
      fName: sp.getString(AppConstants.userName).toString(),
      phone: sp.getString(AppConstants.phone).toString(),
      email: sp.getString(AppConstants.email).toString(),
      id: sp.getInt(AppConstants.userid),
    );
  }

  Future<bool> logOutUser() async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    notifyListeners();
    return sp.clear();
  }

  final GoogleSignIn _googleSignIn = GoogleSignIn();
  GoogleSignInAccount? googleAccount;

  Future<GoogleSignInAuthentication> googleLogin() async {
    googleAccount = await _googleSignIn.signIn();
    GoogleSignInAuthentication auth = await googleAccount!.authentication;
    debugPrint('HELLO=====>${auth.idToken}');

    return auth;
  }

  Future<void> loginWithGoogle(
    String displayName,
    String email,
    BuildContext context,
  ) async {
    User user;
    ApiResponse apiResponse = await authRepo!.checkEmailExist(email);

    if (apiResponse.response != null &&
        apiResponse.response!.statusCode == 200) {
      if (apiResponse.response?.data['msg'].toString() == 'Email Found') {
        int id = apiResponse.response?.data['data'][0]['id'];

        saveUser(Data(
                fName: apiResponse.response?.data['data'][0]['f_name'],
                phone: apiResponse.response?.data['data'][0]['phone'],
                email: apiResponse.response?.data['data'][0]['email'],
                id: id))
            .then((value) async {
          Fluttertoast.showToast(
            msg: "Login successfully",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
          );

          await Navigator.pushNamedAndRemoveUntil(
              context, RoutesName.categoryScreen, (route) => false);
        });
      } else {
        debugPrint("RegisterQuery--->$displayName '::' $email");
        registerWithGoogle(displayName, '', email, context);
      }
    }
  }

  Future<void> socialLogout() async {
    final GoogleSignIn googleSignIn = GoogleSignIn();
    googleSignIn.disconnect();
    SharedPreferences sp = await SharedPreferences.getInstance();
    notifyListeners();
    sp.clear();
  }

  Future<String> checkUserAlredyExist(String mobileNumber, BuildContext context,
      String userName, String type) async {
    _isLoading = true;

    ApiResponse apiResponse = await authRepo!.checkPhoneExist(mobileNumber);

    if (apiResponse.response != null &&
        apiResponse.response!.statusCode == 200) {
      _data = apiResponse.response?.data;
      debugPrint("Success${apiResponse.response?.data['msg']}");
      if (apiResponse.response?.data['msg'] == 'Mobile Number Found') {
        _isLoading = false;
        if (type == 'register') {
          Fluttertoast.showToast(
            msg: "Mobile number already registered please select login.",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
          );
        }
      } else {
        _isLoading = false;

        Navigator.of(context).pushNamed('/verify_otp', arguments: {
          'name': userName.toString().trim(),
          'number': mobileNumber.toString().trim(),
          'type': type,
        });
      }
    } else {
      _data = apiResponse.response!.data;
      _registrationErrorMessage =
          ApiChecker.getError(apiResponse).errors![0].message;
      debugPrint("Error===>" + apiResponse.response?.data);
      // responseModel = ResponseModel(false, _registrationErrorMessage);
    }

    return apiResponse.response?.data['msg'];
  }

  Future<void> sendOtp(String mobileNumber, String userName) async {
    debugPrint("{Login with -----: $mobileNumber $userName}");
    FirebaseAuth auth = FirebaseAuth.instance;
    _isLoading = true;
    await auth.verifyPhoneNumber(
      phoneNumber: '+91$mobileNumber',
      verificationCompleted: (PhoneAuthCredential credential) async {
        await auth.signInWithCredential(credential);
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        _isLoading = false;

        Fluttertoast.showToast(msg: "Timeout");

        debugPrint("Otp codeAutoRetrievalTimeout--->$verificationId");
      },
      codeSent: (String verificationId, int? forceResendingToken) {
        _isLoading = false;
        verificationIDs = verificationId;
        Fluttertoast.showToast(msg: "Otp sent");

        debugPrint("Otp verificationId--->$verificationId");
      },
      verificationFailed: (FirebaseAuthException error) {
        _isLoading = false;
        Fluttertoast.showToast(msg: error.toString());
        debugPrint("Otp verification error--->${error.message}");
      },
    );
  }

  void verifyOTP(String otp, String number, String name, BuildContext context,
      String verificationID, String type) async {
    SharedPreferences sp = await SharedPreferences.getInstance();

    String? referBy = sp.getString("refer_by").toString();

    PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: verificationID, smsCode: otp);

    FirebaseAuth auth = FirebaseAuth.instance;

    await auth.signInWithCredential(credential).then(
      (value) {
        user = FirebaseAuth.instance.currentUser;
      },
    ).whenComplete(
      () async {
        checkUserAlredyExist(number, context, name, type).then((value) => {
              debugPrint("user yes or not $value"),
              if (value == "Mobile Number Not Exist In Our Database")
                {
                  register(user, name, number, '', context, referBy.toString()),
                }
              else
                {
                  login(context, number),
                }
            });
      },
    );
  }

  Future login(context, mobileNumber) async {
    ApiResponse apiResponse = await authRepo!.checkPhoneExist(mobileNumber);

    if (apiResponse.response != null &&
        apiResponse.response!.statusCode == 200) {
      _data = apiResponse.response?.data;
      debugPrint("Success${apiResponse.response?.data['msg']}");
      if (apiResponse.response?.data['msg'] == 'Mobile Number Found') {
        _isLoading = false;

        int id = apiResponse.response?.data['data'][0]['id'];

        debugPrint("User Data ->>>>$id");

        saveUser(Data(
                fName: apiResponse.response?.data['data'][0]['f_name'],
                phone: apiResponse.response?.data['data'][0]['phone'],
                email: apiResponse.response?.data['data'][0]['email'],
                id: id))
            .then((value) async {
          Fluttertoast.showToast(
            msg: "Login successfully",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
          );

          await Navigator.pushNamedAndRemoveUntil(
              context, RoutesName.categoryScreen, (route) => false);
        }).onError((error, stackTrace) {
          debugPrint("Error Login With Otp ->$error");
        });
      }

      await Navigator.pushNamedAndRemoveUntil(
          context, RoutesName.categoryScreen, (route) => false);
    }
  }

  checkIfFirstTime(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool isFirstTime = prefs.getBool('isFirstTime') ?? true;
    if (isFirstTime) {
      print("is first time");

      // Fluttertoast.showToast(msg: "Explore all features in next 10 minitues");
      print('Background task started');
      await prefs.setBool('isFirstTime', false);

      await Future.delayed(const Duration(seconds: 40));

      // Task completed
      print('Background task completed');

      // showDialog(
      //     context: context,
      //     builder: (BuildContext context) {
      //       return AlertDialog(
      //         title: const Text('Alert'),
      //         content: const Text('Your free 10 minutes is end'),
      //         actions: <Widget>[
      //           TextButton(
      //             onPressed: () {
      //               // Navigator.of(context).d();
      //               Navigator.pushNamedAndRemoveUntil(
      //                   context, RoutesName.splash, (route) => false);
      //             },
      //             child: const Text('Close'),
      //           ),
      //         ],
      //       );
      //     });

      // Simulate a task running for 30 seconds
    } else {
      print("not first time");

      // _startTimer1();
    }

    return isFirstTime;
  }

  Future register(User? user, String name, String number, String email, context,
      String referBy) async {
    if (user != null) {
      Data signUpModel = Data(
        fName: name,
        phone: number,
        email: email,
        referBy: referBy,
      );

      print('validateJson--->${signUpModel.toJson()}');

      // print('referBy---->$referBy');

      await registration(signUpModel).then((status) async {
        // print("registration status :::>>>>>>" + status['data']['id']);
        Provider.of<HomeProvider>(context, listen: false)
            .initializePreferences();

        saveUser(Data(
          fName: name,
          phone: number,
          id: status['data']['id'],
          email: email,
        )).then((value) async {
          checkIfFirstTime(context);
          await Navigator.pushNamedAndRemoveUntil(
              context, RoutesName.categoryScreen, (route) => false);
        });
      });
    } else {
      Fluttertoast.showToast(
        msg: "your login is failed",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0,
      );
    }
  }

  Future registerWithGoogle(
      String name, String number, String email, context) async {
    Data signUpModel = Data(
      fName: name,
      email: email,
    );

    await registration(signUpModel).then((status) async {
      //print("registration status :::>>>>>>" + status['data']['id']);

      saveUser(Data(
              fName: name,
              phone: number,
              id: status['data']['id'],
              email: email))
          .then((value) async {
        Provider.of<HomeProvider>(context, listen: false)
            .initializePreferences();

        await Navigator.pushNamedAndRemoveUntil(
            context, RoutesName.categoryScreen, (route) => false);
      });
    }).onError((error, stackTrace) {
      debugPrint('------------> $error');
      Fluttertoast.showToast(
        msg: "Login failed",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0,
      );
    });
  }
}
