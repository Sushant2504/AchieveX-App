import 'package:achievex/utils/colors.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';

import '../provider/auth_provider.dart';
import '../utils/routes/routes_name.dart';
import '../utils/utils.dart';

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    void route(
      bool isRoute,
      String? token,
      String errorMessage,
    ) async {
      if (isRoute) {
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(errorMessage), backgroundColor: Colors.red));
      }
    }

    TextEditingController nameController = TextEditingController();
    TextEditingController mobileNumberController = TextEditingController();

    return Consumer<AppAuthProvider>(builder: (context, authProvider, child) {
      (authProvider.isLoading) ? CircularProgressIndicator : Container();
      return Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Container(
            decoration: const BoxDecoration(),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Wrap(children: [
                  Container(
                    margin: const EdgeInsets.only(right: 25, left: 25, top: 30),
                    decoration: const BoxDecoration(
                        color: AppColors.whitebackgroundColor,
                        borderRadius: BorderRadius.all(Radius.circular(15))),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 25,
                        ),
                        InkWell(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: const Icon(
                              Icons.arrow_back,
                              weight: 20,
                            )),
                        const SizedBox(
                          height: 0,
                        ),
                        const Padding(
                          padding: EdgeInsets.only(right: 12.0, top: 12),
                          child: Text("Create An\nAccount",
                              style: TextStyle(
                                  fontSize: 28,
                                  fontFamily: 'Poppins',
                                  color: AppColors.blackColor,
                                  fontWeight: FontWeight.w700)),
                        ),
                        const Padding(
                          padding: EdgeInsets.only(left: 0.0),
                          child: Text("On \"Achievex X\"",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontFamily: 'Poppins',
                                  color: AppColors.textNewColor,
                                  fontWeight: FontWeight.w700)),
                        ),
                        const SizedBox(
                          height: 34,
                        ),
                        Card(
                          child: Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: AppColors.formBgColor,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey
                                      .withOpacity(0.5), // Shadow color
                                  spreadRadius: 2, // Spread radius
                                  blurRadius: 2, // Blur radius
                                  offset: const Offset(
                                      0, 1), // Offset of the shadow
                                ),
                              ],
                            ),
                            // height: 50,
                            child: TextField(
                              controller: nameController,
                              decoration: InputDecoration(
                                contentPadding:
                                    const EdgeInsets.symmetric(vertical: 10),
                                border: InputBorder.none,
                                prefixIcon: Padding(
                                  padding: const EdgeInsets.all(12.0),
                                  child: Image.asset(
                                    'assets/icons/fname.png',
                                    height: 5,
                                    width: 5,
                                  ),
                                ),
                                hintStyle: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'Poppins'),
                                hintText: 'Full Name',
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        Card(
                          child: Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: AppColors.formBgColor,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey
                                      .withOpacity(0.5), // Shadow color
                                  spreadRadius: 2, // Spread radius
                                  blurRadius: 2, // Blur radius
                                  offset: const Offset(
                                      0, 1), // Offset of the shadow
                                ),
                              ],
                            ),
                            height: 50,
                            child: TextField(
                              keyboardType: TextInputType.phone,
                              controller: mobileNumberController,
                              decoration: InputDecoration(
                                contentPadding:
                                    const EdgeInsets.symmetric(vertical: 10),
                                border: InputBorder.none,
                                prefixIcon: Padding(
                                  padding: const EdgeInsets.all(12.0),
                                  child: Image.asset(
                                    'assets/icons/contact.png',
                                    height: 5,
                                    width: 5,
                                  ),
                                ),
                                hintStyle: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'Poppins'),
                                hintText: 'Phone Number',
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 7,
                        ),
                        const Padding(
                          padding: EdgeInsets.only(left: 10.0, right: 2.0),
                          child: Text(
                            'By creating an account you agree for out Terms of service and Privacy Policy.',
                            style: TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w500),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              const Text('Already An Member ?',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  )),
                              InkWell(
                                onTap: () => {
                                  Navigator.pushNamed(context, RoutesName.login)
                                },
                                child: const Text(' Login',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: AppColors.accentColor,
                                      fontWeight: FontWeight.w600,
                                    )),
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 0.0, right: 0, top: 4),
                          child: InkWell(
                            onTap: () {
                              if (mobileNumberController.text.isNotEmpty &&
                                  nameController.text.isNotEmpty) {
                                if (mobileNumberController.text
                                        .toString()
                                        .length ==
                                    10) {
                                  authProvider.checkUserAlredyExist(
                                      mobileNumberController.text
                                          .toString()
                                          .trim(),
                                      context,
                                      nameController.text.toString().trim(),
                                      "register");
                                } else {
                                  Fluttertoast.showToast(
                                    msg: "Invalid mobile number.",
                                    toastLength: Toast.LENGTH_SHORT,
                                    gravity: ToastGravity.BOTTOM,
                                    timeInSecForIosWeb: 1,
                                    backgroundColor: Colors.red,
                                    textColor: Colors.white,
                                    fontSize: 16.0,
                                  );
                                }
                                // Navigator.pushNamed(context, RoutesName.verifyOtp,arguments: {
                                //   'name':nameController.text,
                                //   'number':mobileNumberController.text,
                                // });
                              } else {
                                Utils.showToast('All fields are required');
                                Utils.showFlushbar(
                                    'All fields are required', context);
                              }
                            },
                            child: Container(
                                height: 50,
                                decoration: BoxDecoration(
                                    color: AppColors.accentColor,
                                    border: Border.all(
                                        width: 2, color: AppColors.textColor),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(5))),
                                child: const Center(
                                    child: Text(
                                  "Get your OTP",
                                  style: TextStyle(
                                    color: AppColors.whiteColor,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ))),
                          ),
                        ),
                        Stack(
                          children: [
                            const Padding(
                              padding: EdgeInsets.only(top: 19.0),
                              child: Divider(
                                thickness: 1,
                                height: 2,
                                color: Colors.black,
                              ),
                            ),
                            Center(
                              child: Container(
                                color: AppColors.whiteColor,
                                child: const Padding(
                                  padding: EdgeInsets.only(
                                      top: 9.0, left: 5, right: 5),
                                  child: Text('Sign in with'),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 19,
                        ),
                        Container(
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            color: AppColors.formBgColor,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey
                                    .withOpacity(0.5), // Shadow color
                                spreadRadius: 2, // Spread radius
                                blurRadius: 2, // Blur radius
                                offset:
                                    const Offset(0, 1), // Offset of the shadow
                              ),
                            ],
                          ),
                          child: InkWell(
                            onTap: () async {
                              try {
                                GoogleSignInAuthentication auth =
                                    await authProvider.googleLogin();

                                GoogleSignInAccount googleAccount =
                                    authProvider.googleAccount!;

                                debugPrint(
                                    'access token is : ${auth.accessToken} username: ${googleAccount.displayName}');

                                authProvider.loginWithGoogle(
                                    googleAccount.displayName.toString(),
                                    googleAccount.email,
                                    context);
                              } catch (er) {
                                debugPrint('access token error is : $er');
                              }
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                IconButton(
                                  onPressed: () {
                                    // Add your onPressed functionality here
                                  },
                                  icon: Image.asset(
                                    'assets/icons/g_login.png', // Replace with your image file path
                                    width: 24, // Set the width of the image
                                    height: 24, // Set the height of the image
                                  ),
                                ),
                                const Text(
                                  'Continue With Google',
                                  style: TextStyle(fontWeight: FontWeight.w700),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        )
                      ],
                    ),
                  ),
                ]),
              ],
            ),
          ),
        ),
      );
    });
  }

  Future<void> handleDeepLinking(BuildContext context) async {
    final PendingDynamicLinkData? initialLink =
        await FirebaseDynamicLinks.instance.getInitialLink();
    if (initialLink != null) {
      final Uri deepLink = initialLink.link;
      // Example of using the dynamic link to push the user to a different screen
      //Navigator.pushNamed(context, deepLink.path);
    }
    FirebaseDynamicLinks.instance.onLink.listen(
      (pendingDynamicLinkData) async {
        final Uri deepLink = pendingDynamicLinkData.link;
        Map<String, String> queryParams = deepLink.queryParameters;
        print("------------>${queryParams['referCode']}");

        if (queryParams['referCode'] != '') {}
        // await serviceLocator<LocalStorage>().saveReferralCode(queryParams['referral_code'] ?? '');
      },
    );
  }
}
