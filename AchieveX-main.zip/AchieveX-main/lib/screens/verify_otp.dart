import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';
import 'package:provider/provider.dart';

import '../provider/auth_provider.dart';
import '../utils/colors.dart';

class VerifyOtpScreen extends StatefulWidget {
  const VerifyOtpScreen({super.key});

  @override
  State<VerifyOtpScreen> createState() => _VerifyOtpScreenState();
}

class _VerifyOtpScreenState extends State<VerifyOtpScreen> {
  FirebaseAuth auth = FirebaseAuth.instance;
  bool otpVisibility = false;
  bool isResendVisible = true;
  User? user;
  String verificationID = "";
  TextEditingController otpController = TextEditingController();
  late AppAuthProvider appAuthProvider;

  @override
  Widget build(BuildContext context) {
    final routesArgs =
        ModalRoute.of(context)?.settings.arguments as Map<String, String>;
    final name = routesArgs['name'].toString();
    final number = routesArgs['number'].toString();
    final type = routesArgs['type'].toString();

    return Consumer<AppAuthProvider>(builder: (context, authProvider, child) {
      authProvider.sendOtp(number, name);
      return Scaffold(
        body: Padding(
          padding: const EdgeInsets.only(top: 48.0, left: 15, right: 15),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.only(left: 0.0),
                child: Text("OTP verification",
                    style: TextStyle(
                        fontSize: 18,
                        fontFamily: 'Poppins',
                        color: AppColors.textNewColor,
                        fontWeight: FontWeight.w700)),
              ),
              const Padding(
                padding: EdgeInsets.only(right: 12.0, top: 12),
                child: Text("Please enter\nOTP verification",
                    style: TextStyle(
                        fontSize: 28,
                        fontFamily: 'Poppins',
                        color: AppColors.blackColor,
                        fontWeight: FontWeight.w700)),
              ),
              Row(
                children: [
                  const Padding(
                    padding: EdgeInsets.only(left: 0.0),
                    child: Text(
                        "If you didn’t received OTP\nverification then Resend in ",
                        style: TextStyle(
                            fontSize: 13,
                            fontFamily: 'Poppins',
                            color: AppColors.textNewColor,
                            fontWeight: FontWeight.w700)),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 0.0),
                    child: Text("\n00:${authProvider.start} ",
                        style: const TextStyle(
                            fontSize: 13,
                            fontFamily: 'Poppins',
                            color: Colors.red,
                            fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
              const SizedBox(
                height: 40,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(
                    height: 80,
                  ),
                  Pinput(
                    length: 6,
                    pinputAutovalidateMode: PinputAutovalidateMode.onSubmit,
                    showCursor: true,
                    onCompleted: (pin) => print(pin),
                    controller: otpController,
                  ),
                  const SizedBox(
                    height: 40,
                  ),
                  // Consumer<AuthProvider>(
                  //   builder: (context, authProvider, child) =>

                  InkWell(
                    onTap: () {
                      authProvider.verifyOTP(
                          otpController.text.toString(),
                          number,
                          name,
                          context,
                          authProvider.verificationIDs,
                          type);
                    },
                    child: Container(
                        height: 50,
                        decoration: BoxDecoration(
                            color: AppColors.accentColor,
                            border: Border.all(
                                width: 2, color: AppColors.textColor),
                            borderRadius:
                                const BorderRadius.all(Radius.circular(5))),
                        child: const Center(
                            child: Text(
                          "Verify",
                          style: TextStyle(
                            color: AppColors.whiteColor,
                            fontSize: 20,
                            fontWeight: FontWeight.w500,
                          ),
                        ))),
                  ),
                  // ),

                  const Padding(
                    padding: EdgeInsets.only(left: 15.0, top: 4, bottom: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [],
                    ),
                  ),
                  const SizedBox(
                    height: 0,
                  ),
                ],
              ),
              Center(
                child: (authProvider.timerRunning)
                    ? const Text(
                        " Resend ?",
                        style: TextStyle(
                            color: AppColors.greyColor,
                            fontWeight: FontWeight.w600),
                      )
                    : InkWell(
                        onTap: () => {
                          authProvider.startTimer(),
                          authProvider.sendOtp(number, name),
                        },
                        child: const Text(
                          " Resend ?",
                          style: TextStyle(
                              color: AppColors.textColor,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
              )
            ],
          ),
        ),
      );
    });
  }
}
