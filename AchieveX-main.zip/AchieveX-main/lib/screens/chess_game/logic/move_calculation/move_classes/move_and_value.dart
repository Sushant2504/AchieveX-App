import 'move.dart';

class MoveAndValue {
  Move move;
  int value;

  MoveAndValue(this.move, this.value);
}
