class Move {
  int value;
  List<int> markup;

  int x, y;

  Move(this.x, this.y, this.value, this.markup);
}
