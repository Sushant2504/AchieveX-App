import 'package:achievex/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';

import '../provider/auth_provider.dart';
import '../utils/utils.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    TextEditingController nameController = TextEditingController();
    TextEditingController mobileNumberController = TextEditingController();
    return Consumer<AppAuthProvider>(builder: (context, authProvider, child) {
      return Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Container(
            decoration: const BoxDecoration(),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Wrap(children: [
                  Container(
                    margin: const EdgeInsets.only(right: 25, left: 25, top: 30),
                    decoration: const BoxDecoration(
                        color: AppColors.whitebackgroundColor,
                        borderRadius: BorderRadius.all(Radius.circular(15))),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 25,
                        ),
                        InkWell(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: const Icon(
                              Icons.arrow_back,
                              weight: 20,
                            )),
                        const SizedBox(
                          height: 0,
                        ),
                        const Padding(
                          padding: EdgeInsets.only(right: 12.0, top: 12),
                          child: Text(
                            "Login",
                            style: TextStyle(
                              fontSize: 28,
                              fontFamily: 'Poppins',
                              color: AppColors.blackColor,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.only(left: 0.0),
                          child: Text(
                            "On \"Achievex X\".",
                            style: TextStyle(
                              fontSize: 16,
                              fontFamily: 'Poppins',
                              color: AppColors.textNewColor,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 34,
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        Card(
                          child: Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: AppColors.formBgColor,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey
                                      .withOpacity(0.5), // Shadow color
                                  spreadRadius: 2, // Spread radius
                                  blurRadius: 2, // Blur radius
                                  offset: const Offset(
                                      0, 1), // Offset of the shadow
                                ),
                              ],
                            ),
                            height: 50,
                            child: TextField(
                              keyboardType: TextInputType.phone,
                              controller: mobileNumberController,
                              decoration: InputDecoration(
                                contentPadding:
                                    const EdgeInsets.symmetric(vertical: 10),
                                border: InputBorder.none,
                                prefixIcon: Padding(
                                  padding: const EdgeInsets.all(12.0),
                                  child: Image.asset(
                                    'assets/icons/contact.png',
                                    height: 5,
                                    width: 5,
                                  ),
                                ),
                                // border: const OutlineInputBorder(),
                                // labelText: 'Mobile Number',
                                // labelStyle:  TextStyle(fontWeight: FontWeight.w700,fontFamily: 'Poppins'),

                                hintStyle: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'Poppins'),
                                hintText: 'Phone Number',
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 7,
                        ),
                        const Padding(
                          padding: EdgeInsets.only(left: 10.0, right: 2.0),
                          child: Text(
                            'Welcome back Achiever please login and continue your journey.',
                            style: TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w500),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 0.0, right: 0, top: 4),
                          child: InkWell(
                            onTap: () {
                              if (mobileNumberController.text.isNotEmpty &&
                                  nameController.text.isNotEmpty) {
                                Navigator.of(context).pushNamed(
                                  '/verify_otp',
                                  arguments: {
                                    'name':
                                        nameController.text.toString().trim(),
                                    'number': mobileNumberController.text
                                        .toString()
                                        .trim(),
                                  },
                                );

                                // Navigator.pushNamed(context, RoutesName.verifyOtp,arguments: {
                                //   'name':nameController.text,
                                //   'number':mobileNumberController.text,
                                // });
                              } else {
                                Utils.showToast('All fields are required');
                                Utils.showFlushbar(
                                    'All fields are required', context);
                              }
                            },
                            child: InkWell(
                              onTap: () => {
                                authProvider
                                    .checkPhone(
                                        mobileNumberController.text.toString())
                                    .then((value) => {
                                          if (value['msg'] ==
                                              'Mobile Number Found')
                                            {
                                              debugPrint("First Name=>" +
                                                  value['data'][0]['f_name']),
                                              Navigator.of(context).pushNamed(
                                                  '/verify_otp',
                                                  arguments: {
                                                    'name': value['data'][0]
                                                            ['f_name']
                                                        .toString(),
                                                    'number':
                                                        '${value['data'][0]['phone']}',
                                                    'id':
                                                        '${value['data'][0]['id']}',
                                                    'type': 'login'
                                                  }),
                                            }
                                        }),
                              },
                              child: Container(
                                  height: 50,
                                  decoration: BoxDecoration(
                                      color: AppColors.accentColor,
                                      border: Border.all(
                                          width: 2, color: AppColors.textColor),
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(5))),
                                  child: const Center(
                                      child: Text(
                                    "Get your OTP",
                                    style: TextStyle(
                                      color: AppColors.whiteColor,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ))),
                            ),
                          ),
                        ),
                        Stack(
                          children: [
                            const Padding(
                              padding: EdgeInsets.only(top: 19.0),
                              child: Divider(
                                thickness: 1,
                                height: 2,
                                color: Colors.black,
                              ),
                            ),
                            Center(
                              child: Container(
                                color: AppColors.whiteColor,
                                child: const Padding(
                                  padding: EdgeInsets.only(
                                      top: 9.0, left: 5, right: 5),
                                  child: Text('Sign in with'),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 19,
                        ),
                        InkWell(
                          onTap: () async {
                            GoogleSignInAuthentication auth =
                                await authProvider.googleLogin();

                            GoogleSignInAccount googleAccount =
                                authProvider.googleAccount!;

                            debugPrint(
                                'access token is : ${auth.accessToken} username: ${googleAccount.displayName}');

                            authProvider.loginWithGoogle(
                                googleAccount.displayName.toString(),
                                googleAccount.email,
                                context);
                          },
                          child: Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: AppColors.formBgColor,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey
                                      .withOpacity(0.5), // Shadow color
                                  spreadRadius: 2, // Spread radius
                                  blurRadius: 2, // Blur radius
                                  offset: const Offset(
                                      0, 1), // Offset of the shadow
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                IconButton(
                                  onPressed: () {
                                    // Add your onPressed functionality here
                                  },
                                  icon: Image.asset(
                                    'assets/icons/g_login.png', // Replace with your image file path
                                    width: 24, // Set the width of the image
                                    height: 24, // Set the height of the image
                                  ),
                                ),
                                const Text(
                                  'Continue With Google',
                                  style: TextStyle(fontWeight: FontWeight.w700),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        )
                      ],
                    ),
                  ),
                ]),
              ],
            ),
          ),
        ),
      );
    });
  }
}
