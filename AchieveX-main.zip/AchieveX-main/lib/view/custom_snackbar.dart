

// void showCustomSnackBar(String? message, {bool isError = true, bool isToast = false}) {
//   final width = MediaQuery.of(Get.context!).size.width;
//   ScaffoldMessenger.of()..hideCurrentSnackBar()..showSnackBar(SnackBar(
//     content: Text(message!),
//     margin: EdgeInsets.all(5),
//     behavior: SnackBarBehavior.floating,
//     backgroundColor: isError ? Colors.red : Colors.green,
//   ));

// }